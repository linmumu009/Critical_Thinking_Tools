# 独立盲评材料

你的固定评审者 ID 是 `reviewer-1`，packet hash 是 `4e0cc330097015365c83c168a0cd8f763ca01b7f36af1254495e54c29eed84b7`。

优先直接打开 `review-form.html`。页面完全离线，进度只保存在本机浏览器；完成后点击“导出 CSV”。请不要与另一位评审者讨论，也不要查阅项目仓库中的协调者目录、自动映射或实验结果。

如果不使用页面，可阅读 `blind-review-packet.md` 并填写 `reviewer-template.csv`。必须完成全部 384 行；映射为 `NONE` 时，“完整可答”填 `0`，映射为 E1-E6 时填 `1`。
